# حمله زامبی ۳بعدی — پروژهٔ اندروید

بازی داخل یک WebView بستهٔ کاملاً آفلاین است (three.js، فونت‌ها و لوگو داخل خود APK هستند؛ اینترنت لازم نیست).

## ساخت APK

### راه ۱: Android Studio
1. پوشهٔ `android` را در Android Studio باز کن.
2. صبر کن Gradle Sync تمام شود.
3. منوی Build ← Build APK(s).
4. فایل در `android/app/build/outputs/apk/debug/app-debug.apk` ساخته می‌شود.

### راه ۲: GitHub Actions (بدون نصب هیچ چیز)
1. یک مخزن جدید در GitHub بساز و کل این پوشه را Push کن.
2. تب Actions ← «Build APK» ← بعد از پایان، فایل `zombie-attack-apk` را از Artifacts دانلود کن.
3. فایل zip را باز کن، `app-debug.apk` را روی گوشی نصب کن (اجازهٔ «نصب از منبع ناشناس» را بده).

## ویرایش بازی
کد بازی: `android/app/src/main/assets/www/index.html`
آیکن برنامه: `android/app/src/main/res/mipmap-*/`
